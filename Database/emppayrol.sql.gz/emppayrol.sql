-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 16, 2018 at 10:51 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `emppayrol`
--

-- --------------------------------------------------------

--
-- Table structure for table `allowance`
--

DROP TABLE IF EXISTS `allowance`;
CREATE TABLE IF NOT EXISTS `allowance` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `overtime` varchar(20) NOT NULL,
  `medical` varchar(20) NOT NULL,
  `bonus` varchar(15) NOT NULL,
  `other` varchar(15) NOT NULL,
  `emp_id` varchar(15) NOT NULL,
  `salary` varchar(15) NOT NULL,
  `rate` varchar(15) NOT NULL,
  `total_allowance` varchar(15) NOT NULL,
  `firstname` varchar(15) NOT NULL,
  `surname` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `allowance`
--

INSERT INTO `allowance` (`id`, `overtime`, `medical`, `bonus`, `other`, `emp_id`, `salary`, `rate`, `total_allowance`, `firstname`, `surname`) VALUES
(1, '12', '12', '12', '12', 'nte001', '60000', '300.0', '5436.0', 'sachith', 'weerasinghe'),
(2, '11', '12', '11', '5', 'nte002', '50000', '250.0', '4153.0', 'adasdad', 'asdasd'),
(3, '2', '3', '4', '2', 'nte003', '45000', '225.0', '684.0', 'sudarshana', 'atapattu'),
(4, '2', '3', '7', '3', 'nte004', '80000', '400.0', '1213.0', 'amila', 'malmeewala'),
(5, '2', '3', '4', '5', 'nte003', '45000', '225.0', '687.0', 'sudarshana', 'atapattu');

-- --------------------------------------------------------

--
-- Table structure for table `deductions`
--

DROP TABLE IF EXISTS `deductions`;
CREATE TABLE IF NOT EXISTS `deductions` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(20) NOT NULL,
  `surname` varchar(20) NOT NULL,
  `salary` varchar(30) NOT NULL,
  `deduction_amount` varchar(30) NOT NULL,
  `deduction_reason` varchar(40) NOT NULL,
  `emp_id` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deductions`
--

INSERT INTO `deductions` (`id`, `firstname`, `surname`, `salary`, `deduction_amount`, `deduction_reason`, `emp_id`) VALUES
(1, 'sachith', 'weerasinghe', '60000', '2000', 'absent', 'nte001'),
(2, 'adasdad', 'asdasd', '50000', '500', 'absent', 'nte002'),
(3, 'sachith', 'weerasinghe', '65872', '500', 'absent', 'nte001');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `empid` varchar(10) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `surname` varchar(20) NOT NULL,
  `dob` varchar(15) NOT NULL,
  `gender` varchar(8) NOT NULL,
  `email` varchar(35) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `address1` varchar(30) NOT NULL,
  `address2` varchar(30) NOT NULL,
  `apt` varchar(15) NOT NULL,
  `post_code` varchar(10) NOT NULL,
  `department` varchar(20) NOT NULL,
  `designation` varchar(15) NOT NULL,
  `status` varchar(10) NOT NULL,
  `date_hired` varchar(15) NOT NULL,
  `basic_sal` varchar(20) NOT NULL,
  `job_title` varchar(15) NOT NULL,
  PRIMARY KEY (`empid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`empid`, `first_name`, `surname`, `dob`, `gender`, `email`, `contact`, `address1`, `address2`, `apt`, `post_code`, `department`, `designation`, `status`, `date_hired`, `basic_sal`, `job_title`) VALUES
('nte001', 'sachith', 'weerasinghe', 'Jun 20, 1994', 'Male', 'sma@gmail.com', '0777978688', 'pussella', 'pusselithenna', 'sinhavila', '60073', 'kandy', 'engineer', 'Full Time', 'Jun 6, 2018', '65872', 'juniroSE'),
('nte002', 'chamara', 'madhushan', 'Oct 15, 1996', 'Male', 'chan@yahoo.com', '0777845123', 'mawathagama', 'kurunegala', 'no5', 'erqwer', 'colombo', 'system desogn', 'On Call', 'Oct 21, 2018', '50000', 'SE'),
('nte003', 'sudarshana', 'atapattu', 'Oct 9, 1996', 'Male', 'zudar@gmail.com', '0711478459', 'algama', 'pothuhara', 'no11', '65478', 'Kandy', 'engineer', 'Part Time', 'Oct 1, 2018', '45000', 'softwareEN'),
('nte004', 'amila', 'malmeewala', 'Oct 7, 1998', 'Male', 'blackcarbonfeast@gmail.com', '0778945124', 'millawa', 'pilassa', 'no9', '45678', 'galle', 'engineer', 'Full Time', 'Oct 1, 2018', '80000', 'web developer'),
('nte005', 'chamode', 'wee', 'Oct 16, 1998', 'Male', 'chod@yandex.com', '0777874512', 'maharagama', 'colombo', 'no3', '4567', 'Gampaha', 'engineer', 'Part Time', 'Oct 1, 2018', '80000', 'SE'),
('nte006', 'thilina', 'wijekon', 'Oct 4, 1999', 'Male', 'thill@gmail.com', '0784512369', 'walahanduwa', 'galle', 'no9', '789456', 'galle', 'engineer', 'On Call', 'Oct 1, 2018', '75000', 'SE');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `division` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `password`, `id`, `division`) VALUES
('admin', 'emp@123prnibm', 1, 'Admin'),
('sachith', 'sa#123Nibm', 2, 'Sales'),
('sudarshana', 'suda@1234', 3, 'Sales'),
('chamara', 'ch#512222', 4, 'Sales');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
